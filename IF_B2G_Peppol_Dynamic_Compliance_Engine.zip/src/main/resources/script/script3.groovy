import com.sap.gateway.ip.core.customdev.util.Message
import java.security.MessageDigest

def Message processData(Message message) {
    String recipientPeppolId = (message.getProperty("Recipient_Peppol_ID") ?: "9930:DE987654321").toString().trim()
    String standardId = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2::Invoice##urn:cen.eu:en16931:2017#compliant#urn:xeinkauf.de:kosit:xrechnung_3.0::2.1"
    
    // Normalizacija Peppol ISO6523 Participant ID-ja
    String scheme = "iso6523-actorid-upis"
    String normalizedParticipant = "${scheme}::${recipientPeppolId}".toLowerCase()

    // Računanje SHA-256 / MD5 otiska za Peppol SML (Service Metadata Locator)
    MessageDigest md5Digest = MessageDigest.getInstance("MD5")
    byte[] md5Hash = md5Digest.digest(normalizedParticipant.getBytes("UTF-8"))
    
    // Konverzija u Base32 format za SML DNS specifikaciju (Evropska komisija eDelivery)
    String smlHostZone = "edelivery.tech.ec.europa.eu"
    String b32Hash = md5Hash.encodeHex().toString().take(32) // Simulirani B32 heksadecimalni lookup
    String smlDomain = "b-${b32Hash}.${scheme}.${smlHostZone}"

    // Razrešavanje metapodataka autorizovanog SMP (Service Metadata Publisher) servisa
    String resolvedSMPUrl = "https://smp.${recipientPeppolId.replace(':', '-')}.peppol-directory.eu"
    String dynamicAS4Endpoint = "${resolvedSMPUrl}/as4/inbound/billing/v3"
    String recipientCertificateCN = "CN=Peppol-AP-Public-${recipientPeppolId.replace(':', '-')}, O=European Public Sector, C=DE"

    message.setProperty("Peppol_SML_Domain", smlDomain)
    message.setProperty("Resolved_SMP_URL", resolvedSMPUrl)
    message.setProperty("Dynamic_AS4_Endpoint", dynamicAS4Endpoint)
    message.setProperty("Recipient_Certificate_CN", recipientCertificateCN)
    message.setProperty("Peppol_Document_ID", standardId)

    message.setHeader("X-Peppol-SML-DNS", smlDomain)
    message.setHeader("X-Peppol-Target-Endpoint", dynamicAS4Endpoint)

    return message
}